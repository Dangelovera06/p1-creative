import React from "react";
export default function Footer() {
  return (
    <footer className="py-8 bg-black text-white text-center">
      <p>&copy; {new Date().getFullYear()} P1 Creative. All rights reserved.</p>
    </footer>
  );
}