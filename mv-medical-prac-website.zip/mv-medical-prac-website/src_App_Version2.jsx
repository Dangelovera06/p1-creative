import React from "react";
import Hero from "./components/landing/Hero";
import Services from "./components/landing/Services";
import Results from "./components/landing/Results";
import Testimonials from "./components/landing/Testimonials";
import About from "./components/landing/About";
import Contact from "./components/landing/Contact";
import Footer from "./components/landing/Footer";

function App() {
  return (
    <div className="min-h-screen bg-white">
      <Hero />
      <Services />
      <Results />
      <Testimonials />
      <About />
      <Contact />
      <Footer />
    </div>
  );
}

export default App;