import React from "react";
export default function About() {
  return (
    <div className="py-24 bg-gray-100 text-center">
      <h2 className="text-3xl font-bold mb-4">About Us</h2>
      <p className="text-lg text-gray-700">About your agency goes here.</p>
    </div>
  );
}