import React from "react";
export default function Testimonials() {
  return (
    <div className="py-24 bg-white text-center">
      <h2 className="text-3xl font-bold mb-4">Testimonials</h2>
      <p className="text-lg text-gray-700">Client testimonials go here.</p>
    </div>
  );
}