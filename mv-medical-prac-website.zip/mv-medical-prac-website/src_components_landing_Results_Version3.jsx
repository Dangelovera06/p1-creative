import React from "react";
export default function Results() {
  return (
    <div className="py-24 bg-gray-100 text-center">
      <h2 className="text-3xl font-bold mb-4">Results</h2>
      <p className="text-lg text-gray-700">Case studies and proven results go here.</p>
    </div>
  );
}